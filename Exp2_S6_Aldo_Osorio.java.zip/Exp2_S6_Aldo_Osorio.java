/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exp2_s6_aldo_osorio;

/**
 *
 * @author aldoosorio
 */
import java.util.Scanner;

public class Exp2_S6_Aldo_Osorio {

    static String nombreTeatro = "Teatro Moro";
    static int anioBoleta = 2024;
    static int totalEntradas = 10;

    static int valorGeneral = 5000;
    static int valorVIP = 7000;
    static int valorPlatea = 6000;

    public static class Boleta {

        double precio;
        String tipoEntrada;
        int cantidad;

    };

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scanner = new Scanner(System.in);

        String opcion, opcionTipoEntrada, opcionTipoCliente, opcionBoleta;
        double valorFinalEntrada = 0.0;

        int entradasDisponibles = 5;

        while (entradasDisponibles != 0) {

            System.out.print("****************************************\n");
            System.out.println("Bienvenido a " + nombreTeatro);
            System.out.print("****************************************\n");
            System.out.println("");
            System.out.println("(1) Comprar entradas ");
            System.out.print("****************************************\n");
            System.out.print("****************************************\n");
            System.out.println("Ingrese su opcion del menu principal");
            opcion = scanner.nextLine();

            Boleta boleta = new Boleta();
            boleta.cantidad = 1;

            if (opcion.equals("1")) {

                System.out.print("****************************************\n");
                System.out.print("Tipos de entradas disponibles\n ");
                System.out.print("1 : GENERAL\n ");
                System.out.print("2 : VIP\n ");
                System.out.print("3 : PLATEA \n ");
                System.out.print("****************************************\n");
                //capturar por pantalla el tipo de entrada
                System.out.print("Ingrese el tipo de entrada ");
                opcionTipoEntrada = scanner.nextLine();
                boleta.cantidad = 1;
                //Caoturar por pantalla el tipo Cliente
                System.out.print("****************************************\n");
                System.out.print("Tipos de clientes disponibles\n ");
                System.out.print("1 : ESTUDIANTE\n ");
                System.out.print("2 : GENERAL\n ");
                System.out.print("3 : TERCERA EDAD\n ");
                System.out.print("****************************************\n");
                System.out.print("Ingrese el tipo de cliente: ");

                opcionTipoCliente = scanner.nextLine();

                if (opcionTipoCliente.equals("1")) {

                    if (opcionTipoEntrada.equals("1")) {

                        valorFinalEntrada = valorGeneral * 0.90;
                        boleta.tipoEntrada = "General";
                    } else if (opcionTipoEntrada.equals("2")) {
                        valorFinalEntrada = valorVIP * 0.90;
                        boleta.tipoEntrada = "VIP";

                    } else if (opcionTipoEntrada.equals("3")) {
                        valorFinalEntrada = valorPlatea * 0.90;
                        boleta.tipoEntrada = "Platea";

                    }
                    entradasDisponibles = entradasDisponibles - 1;
                    System.out.print("Entradas disponibles =  " + entradasDisponibles);

                } else if (opcionTipoCliente.equals("2")) {

                    if (opcionTipoEntrada.equals("1")) {

                        System.out.print("****************************************\n");
                        System.out.println("Cuantas entradas deseas comprar?");
                        System.out.print("****************************************\n");
                        Integer cantidadEntradas = Integer.parseInt(scanner.nextLine());
                        valorFinalEntrada = (valorGeneral * cantidadEntradas) * 0.95;
                        entradasDisponibles = entradasDisponibles - cantidadEntradas;
                        boleta.tipoEntrada = "General";
                        boleta.cantidad = cantidadEntradas;
                    } else if (opcionTipoEntrada.equals("2")) {
                        valorFinalEntrada = valorVIP;
                        entradasDisponibles = entradasDisponibles - 1;
                        boleta.tipoEntrada = "VIP";

                    } else if (opcionTipoEntrada.equals("3")) {
                        valorFinalEntrada = valorPlatea;
                        entradasDisponibles = entradasDisponibles - 1;
                        boleta.tipoEntrada = "Platea";
                    }
                    // System.out.print("Entradas disponibles =  " + entradasDisponibles);

                } else if (opcionTipoCliente.equals("3")) {

                    if (opcionTipoEntrada.equals("1")) {

                        valorFinalEntrada = valorGeneral * 0.85;
                        boleta.tipoEntrada = "General";
                    } else if (opcionTipoEntrada.equals("2")) {
                        valorFinalEntrada = valorVIP * 0.85;
                        boleta.tipoEntrada = "VIP";

                    } else if (opcionTipoEntrada.equals("3")) {
                        valorFinalEntrada = valorPlatea * 0.85;
                        boleta.tipoEntrada = "VIP";

                    }
                    entradasDisponibles = entradasDisponibles - 1;
                    //System.out.print("Entradas disponibles =  " + entradasDisponibles);
                }

                System.out.println("Precio Final:  $" + valorFinalEntrada);
                boleta.precio = valorFinalEntrada;
                System.out.print("****************************************\n\n");

            }
            System.out.print("****************************************\n");
            System.out.println("(2) Imprimir Boleta     \n");
            System.out.print("****************************************\n");
             opcionBoleta= scanner.nextLine();
            if (opcionBoleta.equals("2")) {
               // Promociones
                System.out.println("-------------------------------------------------------------------------------\n");
                System.out.println("----------  Teatro Moro" + " Periodo " + anioBoleta + "  ------------------------ ");
                System.out.println("--------  Boleta de Compra  ---------------------------------------------------");
                System.out.println("\n-----------------------------------------------------------------------------\n");
                System.out.println("Tipo de Entrada     : " + boleta.tipoEntrada);
                System.out.println("Cantidad de Entradas: " + boleta.cantidad);
                System.out.println("\n-----------------------------------------------------------------------------\n\n");
                System.out.println("Precio Total        : " + boleta.precio + "\n");
                System.out.println("\n-----------------------------------------------------------------------------\n\n");
            }

        }

        System.out.println("No quedan entradas disponibles");
    }
}
